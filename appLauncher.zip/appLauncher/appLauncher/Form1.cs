﻿using System;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace appLauncher
{
    public partial class Form1 : Form
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
    (
        int nLeftRect,
        int nTopRect,
        int nRightRect,
        int nBottomRect,
        int nWidthEllipse,
        int nHeightEllipse
    );

        string url = ""; string dizin = ""; string dosya = "";      string appname = "Site Clone";

        public Form1()
        {
            InitializeComponent();

            Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 40, 40));
        }
        public string sonuc;
        private void Form1_Load(object sender, EventArgs e)
        {


            panel1.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel1.Width, panel1.Height, 40, 40));
            panel2.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel2.Width, panel2.Height, 40, 40));
            panel4.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel4.Width, panel4.Height, 40, 40));
            panel5.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel5.Width, panel5.Height, 40, 40));

            label2.Text = appname;

            try
            {
                WebRequest SiteyeBaglantiTalebi = HttpWebRequest.Create("https://graxypy.github.io/appinfo/");
                WebResponse GelenCevap = SiteyeBaglantiTalebi.GetResponse();
                StreamReader CevapOku = new StreamReader(GelenCevap.GetResponseStream());
                string KaynakKodlar = CevapOku.ReadToEnd();
                int IcerikBaslangicIndex = KaynakKodlar.IndexOf("<appLauncher-siteclone>") + 23;
                int IcerikBitisIndex = KaynakKodlar.Substring(IcerikBaslangicIndex).IndexOf("</appLauncher-siteclone>");

                sonuc = KaynakKodlar.Substring(IcerikBaslangicIndex, IcerikBitisIndex);

                label4.Text = label4.Text + sonuc;
            }
            catch
            {
                MessageBox.Show("Sunucuyla bağlantı kurulamadı", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }

            if (Properties.Settings.Default.version != "NULL")
            {

                if (Properties.Settings.Default.version == sonuc)
                {
                    label3.Text = "Uygulamayı Çalıştır";
                }
                else
                {
                    label3.Text = "Uygulamayı Güncelle";
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            yukle();
        }

        private void panel4_Click(object sender, EventArgs e)
        {
            yukle();
        }



        private void yukle()
        {
            var a = new WebClient();

            try
            {
                a.DownloadFile(url, @"C:\Users\BORG\" + dizin + dosya + ".zip");

                if (File.Exists(@"C:\Users\BORG\" + dosya))
                {
                    string zp = @"C:\Users\BORG\" + dizin + dosya + ".zip";
                    string cp = @"C:\Users\BORG\" + dizin;

                    ZipFile.ExtractToDirectory(zp, cp);

                    if (Directory.Exists(@"C:\Users\BORG\" + dizin))
                    {
                        File.Delete(@"C:\Users\BORG\" + dizin + dosya + ".zip");
                    }
                }

                Application.Restart();
            }
            catch
            {
                MessageBox.Show("Sunucudan veri gönderilmedi", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
